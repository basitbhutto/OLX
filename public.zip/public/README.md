# OLX-Pakistan
SIMT Module 1 Final Project

Functionality :
1) Authentication On Sign Up And Sign In
2) Categories Of Ads
3) Search Ads 
4) Search Ads By Categories
5) Submit An Ad
6) Ad Details Like : Name,Description,Price ...
7) Send Messages On Ad TO Seller/Buyer 
8) Add Ad To Favourites To View Later And Can be Viewed Offline 

PWA Features :
1) Add To Home Screen Pop Up
2) Manifest.json
3) Offline Availablity With Service-worker.js 
